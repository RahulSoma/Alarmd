﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();            
            //WindowStartupLocation = System.Windows.WindowStartupLocation.CenterScreen;
        }

        private void btnProcess_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Reading Data from HTML", "Step 1", MessageBoxButton.OK, MessageBoxImage.Information);
            bFirstStep.Background = Brushes.DeepSkyBlue;
            bFirstStep.IsEnabled = true;
            MessageBox.Show("Applying Filter Conditions", "Step 2", MessageBoxButton.OK, MessageBoxImage.Information);
            bSecondStep.Background = Brushes.OrangeRed;
            bSecondStep.IsEnabled = true;
            MessageBox.Show("Processing The Message Count", "Step 3", MessageBoxButton.OK, MessageBoxImage.Information);
            bThirdStep.Background = Brushes.HotPink;
            bThirdStep.IsEnabled = true;
            MessageBox.Show("Exporting Data to Excel", "Step 4", MessageBoxButton.OK, MessageBoxImage.Information);
            bFourthStep.Background = Brushes.Purple;
            bFourthStep.IsEnabled = true;
            MessageBox.Show("Excel Generated Successfully", "Step 5", MessageBoxButton.OK, MessageBoxImage.Information);
            bFifthStep.Background = Brushes.LawnGreen;
            bFifthStep.IsEnabled = true;
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }        
    }
}
